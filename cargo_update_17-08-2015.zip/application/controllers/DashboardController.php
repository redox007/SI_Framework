<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of DashboardController
 *
 * @author Suchandan
 */
class DashboardController extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->auth(admin_base_url('login'));
    }
    
    public function index() {
        $this->setViewData('title', "Dashboard");
        $this->data['user_count'] = $this->Model_common->countData(TBL_PASSENGER);
        $this->data['order_count'] = $this->Model_common->countData(TBL_ORDERS);
        $this->data['driver_count'] = $this->Model_common->countData(TBL_DRIVER);
        $this->data['booking_count'] = $this->Model_common->countData(TBL_BOOKING);
//        $this->debug_view();
        $this->render_view('dashboard');
    }

}

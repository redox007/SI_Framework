<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of OrderController
 * @property Model_order $Model_order Model_order
 * @author Suchandan
 */
class OrderController extends MY_Controller {

    public function __construct() {
        parent::__construct();
        $this->auth(admin_base_url('login'));
    }

    public function register() {
        $this->loadS_model('order');
        
        $this->setViewData('panel_heading', "Order info");
        $this->setViewData('action', "insert");
        
        $this->add_style('assets/vendors/timepicker/jquery.timepicker.css');
        $this->add_script('assets/vendors/timepicker/jquery.timepicker.min.js',true);
        
        $this->add_style('assets/vendors/autocomplete/autocomplete.css');
        $this->add_script('assets/vendors/autocomplete/jquery.autocomplete.min.js',true);
                
        $this->add_auto_load_script('google_map');
        $this->add_auto_load_script('booking',true);

        $this->setViewData('timeframes', $this->Model_order->getDatas(TBL_TIMEFRAME_MASTER));
        $this->render_view('register', 'order');
    }

    public function update() {
        
    }

    public function lists() {
        
    }

}

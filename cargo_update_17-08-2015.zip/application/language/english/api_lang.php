<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/*
 * This language file is used for web_api web service
 */

$lang['invalid_user'] = "Invalid user ID or password.";
$lang['user_registered'] = "Passenger is successfully registered.";
$lang['user_updated'] = "The passenger successfuly updated.";
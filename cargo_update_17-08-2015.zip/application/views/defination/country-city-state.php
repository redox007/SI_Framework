<div id="country-state-city">
    <div class="row-fluid sortable ui-sortable">
        <?php load_view('city', 'defination'); ?>
        <?php load_view('state', 'defination'); ?>
    </div>
    <div class="row-fluid sortable ui-sortable">
        <?php load_view('country', 'defination'); ?>
    </div>
</div>

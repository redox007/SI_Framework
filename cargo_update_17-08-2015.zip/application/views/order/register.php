<div class="row-fluid sortable ui-sortable">
    <div class="box span6">
        <div class="box-header" data-original-title="">
            <h2><i class="halflings-icon edit"></i><span class="break"></span><?php __e($panel_heading); ?></h2>
        </div>
        <div class="box-content">
            <form class="form-horizontal ajax-form" data-before_submit="before_booking_form_submit" data-after_submit="" action="" method="post" enctype="multipart/form-data">
                <fieldset> 
                    <div class="control-group">
                        <label class="control-label" for="passenger_id">Passenger</label>
                        <div class="controls">
                            <input type="text" name="passenger_id" class="input-xlarge" id="passenger_id" value="<?php __efd('passenger_id', $data_object); ?>">
                            <input type="hidden" name="passenger_id" class="lat" />
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label" for="pickup-addr">Pickup </label>
                        <div class="controls">
                            <input type="text" name="pick_up" class="input-xlarge" id="pickup-addr" value="<?php __efd('pick_up', $data_object); ?>">
                            <input type="hidden" name="pick_lat" class="lat" />
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label" for="drop-addr">Drop </label>
                        <div class="controls">
                            <input type="text" name="drop" class="input-xlarge" id="drop-addr" value="<?php __efd('pick_up', $data_object); ?>">
                            <input type="hidden" name="drop_lat" class="long" />
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label" for="dates">Dates </label>
                        <div class="controls">
                            <input type="text" name="dates" class="input-xlarge multidate_picker" id="dates" value="<?php __efd('dates', $data_object); ?>">
                        </div>
                    </div>
                    <div class="control-group">
                        <label class="control-label" for="dates">Time </label>
                        <div class="controls">
                            <input id="timepicker" class="form-control" data-provide="timepicker" data-template="modal" data-minute-step="1" data-modal-backdrop="true" type="text"/>
                            <?php __e(form_checkbox('is_flexible', 1, (isset($data_object['is_flexible']) && $data_object['is_flexible'] == 1), 'id="is_flexi"')); ?>Flexible
                            <div class="hideme" id="timeframe">
                                <?php
                                foreach ($timeframes as $timeframe) {
//                                    debug($timeframe); 

                                    $tf = date('h a', strtotime($timeframe['start'])) . ' - ' . date('h a', strtotime($timeframe['end']));
                                    __e(form_radio('flexible_timeslot', $timeframe['id'], (isset($data_object['flexible_timeslot']) && $data_object['flexible_timeslot'] == $timeframe['id']), "id='Timeframe" . $timeframe['id'] . "'"));
                                    ?>
                                    <label for="<?php __e("Timeframe{$timeframe['id']}") ?>"><?php __e($tf . "( {$timeframe['discount']}% )"); ?></label>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                    <div class="form-actions">
                        <input type="hidden" name="action" value="<?php __e($action, 'insert'); ?>" />
                        <button type="submit" class="btn btn-primary">Save changes</button>
                        <!--<button type="reset" class="btn">Cancel</button>-->
                    </div>
                </fieldset>
            </form>   

        </div>
    </div><!--/span-->
    <div class="box span6">
        <div class="box-header" data-original-title="">
            <h2><i class="halflings-icon edit"></i><span class="break"></span>Map</h2>
        </div>
        <div class="box-content">  
            <div id="map-canvas" class="map-view">

            </div>
            <div id="direction-panel">

            </div>
        </div>
    </div><!--/span-->
</div>
<script type="text/javascript">
    function before_booking_form_submit(formData, jqForm, options) {
        logme('FOrm Data', formData);
        return false;
    }
    $(function () {
        $('#sender').autocomplete({
            serviceUrl: '<?php echo base_url('ajax/get_passengers'); ?>',
            onSelect: function (suggestion) {
//                alert('You selected: ' + suggestion.value + ', ' + suggestion.data);
            },
            paramName : 's'
        });
    });
</script>


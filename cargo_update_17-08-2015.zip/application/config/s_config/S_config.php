<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

$config['dashboard_url'] = 'dashboard';
$config['dashboard_name'] = 'Cargo Panel';

$config['list_item_numbers'] = 10;
$config['list_page_numbers'] = 3;


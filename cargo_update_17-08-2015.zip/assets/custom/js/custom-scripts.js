/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


$('body').on('click', 'a.delete', function (e) {
    var a = confirm("Do you want to delet this?");
    if (!a) {
        e.preventDefault();
    }
});

function blockUi(element, text) {
    text = text || "Processing";
    $(element).block({
        message: '<h5>'+text+'</h5>',
        css: {border: '1px solid #a00'}
    });
}
function unBlockUi(element) {
    $(element).unblock(); 
}